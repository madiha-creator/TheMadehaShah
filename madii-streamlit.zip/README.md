# Madii's personal website (Streamlit)

Files:
- app.py            -> the Streamlit app (shows the website)
- index.html        -> the whole website (edit your text in the ME block near the bottom)
- requirements.txt  -> Python packages
- .streamlit/config.toml -> colors

Run on your computer:
    pip install -r requirements.txt
    streamlit run app.py

Deploy on Streamlit Community Cloud:
1. Push this folder to a GitHub repo (app.py at the top level).
2. Go to https://share.streamlit.io and sign in with GitHub.
3. Click "Create app", pick your repo and branch (main), set Main file path to app.py.
4. Click Deploy.
